#ifndef _adventure_cpp_
#define _adventure_cpp_

#include "defs.h"

//your code should be after that directive

WarriorTree*  revenge(eventList* pEvent)
{
	WarriorTree* pTree = NULL; 
	//to do
	return pTree;
}

//your code should be before that directive
#endif
