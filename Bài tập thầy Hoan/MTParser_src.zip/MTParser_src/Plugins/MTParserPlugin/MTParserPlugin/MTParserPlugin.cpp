// MTParserPlugin.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{CE936DE7-B62A-4C7E-B9B7-5BCF7EF425AA}", 
		 name = "MTParserPlugin", 
		 helpstring = "MTParserPlugin 1.0 Type Library",
		 resource_name = "IDR_MTPARSERPLUGIN") ]
class CMTParserPluginModule
{
public:
// Override CAtlDllModuleT members
};
		 
