#ifndef _LOCALIZATION_INCLUDED
#define _LOCALIZATION_INCLUDED

#include "../../../MTParserLib/MTParserLocalizer.h"

CString RToS(unsigned int id);

MTSTRING getAllExceptionString(const MTParserException &e);

#endif