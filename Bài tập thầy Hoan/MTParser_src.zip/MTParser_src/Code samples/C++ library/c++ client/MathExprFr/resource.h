//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MathExpr.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MATHEXPR_DIALOG             102
#define IDS_MSG_NEWMACRODEFINED         102
#define IDS_COLNAME_SYMBOL              103
#define IDS_COLNAME_USAGE               104
#define IDS_COLNAME_DESCRIPTION         105
#define IDR_MAINFRAME                   128
#define IDD_INDEXDLG                    130
#define IDD_DEFINEMACRO                 131
#define IDS_COLNAME_PROTOTYPE           132
#define IDS_COLNAME_PARAMETERS          133
#define IDR_MENU1                       133
#define IDS_DEFFORMULA                  134
#define IDS_MSG_INITERROR               135
#define IDS_TITLE_INDEXUNAVAILABLE      136
#define IDS_TITLE_NUMALGOPLUGIN         137
#define IDS_TITLE_DATEPLUGIN            138
#define IDS_USEDVARIABLES               139
#define IDS_NOVARIABLEUSED              140
#define IDS_CONSTEXPR                   141
#define IDS_INVALIDRESULT               142
#define IDS_TITLE_EVALBENCHRESULT       143
#define IDS_TITLE_COMPILBENCHRESULT     144
#define IDS_MSG_BENCHERROR              145
#define IDS_TIMEPEREVAL                 146
#define IDS_EVALPERSEC                  147
#define IDS_TIMEPERCOMP                 148
#define IDS_COMPPERSEC                  149
#define IDS_BENCHPROCESSING             150

#define IDC_EXPR                        1000
#define IDC_VARX                        1001
#define IDC_VARY                        1002
#define IDC_VARZ                        1003
#define IDC_EVALUATE                    1004
#define IDC_MSG                         1005
#define IDC_BENCHMARK                   1006
#define IDC_SETEXPR                     1007
#define IDC_RESULT                      1008
#define IDC_INDEX                       1010
#define IDC_DEFINEDOPS                  1011
#define IDC_DEFINEDFUNCS                1012
#define IDC_SYMBOL                      1012
#define IDC_FUNCTION                    1013
#define IDC_DESCRIPTION                 1014
#define IDC_DEFINEDCONSTS               1015
#define IDC_DEFINEMACRO                 1015
#define IDC_DEFINEDCONVFUNC             1016
#define IDC_BENCHEVAL                   1019
#define IDC_BENCHCOMP                   1020
#define IDC_MSGICON                     1024
#define ID_FILE_EXIT                    32771
#define ID_LANGUAGES_FRENCH             32773
#define ID_LANGUAGES_ENGLISH            32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
