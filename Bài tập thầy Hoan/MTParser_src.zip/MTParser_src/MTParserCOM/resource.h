//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MTParserCOM.rc
//
#define IDS_PROJNAME                    100
#define IDR_MTPARSER                    102
#define IDR_MTDOUBLE                    103
#define IDR_MTDATE                      106
#define IDR_MTPARSERLOCALIZER           107
#define IDR_MTATLEXCEPDATA              108
#define IDR_MTDOUBLEVECTOR              109
#define IDB_SPLASH                      201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
