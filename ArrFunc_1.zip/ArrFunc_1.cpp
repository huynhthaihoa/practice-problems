// VIET CHUONG TRINH BANG C CHUAN
#include <stdio.h>
void Output(int n,int* A);
void Input(int* n,int* A);
main()
{
	int A[100], n;
	Input(&n,A);
	Output(n,A);
}
void Input(int* n,int* A)
{
	int i; 
	printf("Input n: ");
	scanf("%d",n);
	for (i=0;i<*n;i++)
	{
		printf("A[%d]: ",i);
		scanf("%d",&A[i]);	
	}
}
void Output(int n,int* A)
{
	int i;
	printf("\n");
	for (i=0;i<n;i++)
		printf("%3d",A[i]);
}

